package com.example.spidermanmod.entity;

import com.example.spidermanmod.SpiderManMod;
import net.minecraft.entity.EntityClassification;
import net.minecraft.entity.EntityType;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModEntities {

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITIES, SpiderManMod.MOD_ID);

    public static final RegistryObject<EntityType<WebProjectile>> WEB_PROJECTILE =
            ENTITIES.register("web_projectile",
                    () -> EntityType.Builder.<WebProjectile>of(WebProjectile::new, EntityClassification.MISC)
                            .sized(0.25f, 0.25f)
                            .clientTrackingRange(4)
                            .updateInterval(10)
                            .build("web_projectile"));
}
