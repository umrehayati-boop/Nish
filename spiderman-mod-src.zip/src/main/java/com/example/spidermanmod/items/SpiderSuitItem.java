package com.example.spidermanmod.items;

import com.example.spidermanmod.SpiderManMod;
import com.example.spidermanmod.capabilities.SpiderCapability;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.IArmorMaterial;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

public class SpiderSuitItem extends Item {

    public SpiderSuitItem() {
        super(new Item.Properties()
                .tab(net.minecraft.item.ItemGroup.TAB_MISC)
                .stacksTo(1)
                .durability(0));
    }

    @Override
    public ActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        if (!world.isClientSide) {
            SpiderCapability.getSpiderData(player).ifPresent(data -> {
                if (!data.hasPowers()) {
                    data.setPowers(true);
                    player.sendMessage(new StringTextComponent(
                            TextFormatting.RED + "★ " +
                            TextFormatting.GOLD + "Sam Raimi Spider-Man kostümünü giydin!" +
                            TextFormatting.RED + " ★"), player.getUUID());
                    player.sendMessage(new StringTextComponent(
                            TextFormatting.YELLOW + "Örümcek güçleri aktif! Duvar tırmanma, ağ atma ve süper güç kazandın!"), player.getUUID());
                    player.sendMessage(new StringTextComponent(
                            TextFormatting.AQUA + "[R] tuşu ile ağ modunu değiştirebilirsin!"), player.getUUID());
                } else {
                    player.sendMessage(new StringTextComponent(
                            TextFormatting.RED + "Zaten örümcek güçlerine sahipsin!"), player.getUUID());
                }
            });
        }
        return ActionResult.success(player.getItemInHand(hand));
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable World world, List<ITextComponent> tooltip, ITooltipFlag flag) {
        tooltip.add(new StringTextComponent(TextFormatting.RED + "Sam Raimi'nin efsanevi kostümü!"));
        tooltip.add(new StringTextComponent(TextFormatting.GRAY + "Sağ tık: Kostümü giy ve güçleri al"));
        tooltip.add(new StringTextComponent(TextFormatting.YELLOW + "• Duvar Tırmanma"));
        tooltip.add(new StringTextComponent(TextFormatting.YELLOW + "• Ağ Atma (4 mod)"));
        tooltip.add(new StringTextComponent(TextFormatting.YELLOW + "• Süper Güç & Hız"));
        tooltip.add(new StringTextComponent(TextFormatting.YELLOW + "• Düşme Hasarı Yok"));
    }
}
